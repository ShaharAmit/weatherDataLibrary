﻿using System;

namespace WeatherLib {
    public class WeatherDataException : ApplicationException {
        public WeatherDataException(String message) {
            if(message.Equals("1")) {
                Console.WriteLine("wrong xml parse");
            } else if(message.Equals("2")) {
                Console.WriteLine("check your comparsion of 'open_weather_map'");
            } else if(message.Equals("3")) {
                Console.WriteLine("check your printing method");
            }
        }
    }
}
