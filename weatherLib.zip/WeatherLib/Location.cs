﻿using System;

namespace WeatherLib {
    public class Location {
        private String city_name;
        private String country_code;
        private String sunrise;
        private String sunset;
        private String day_of_the_week;
        private String sky_condition;
        private String wind;
        private String wind_des;
        private String wind_dir;
        private String min_temperature;
        private String max_temperature;
        private String pressure;
        private String humidity;
        private String clouds;
        
        public Location(String location) {
            city_name = location;
        }

        public String City_name {
            get { return city_name; }
            set { city_name = value; }
        }

        public String Country_code {
            get { return country_code; }
            set { country_code = value; }
        }

        public String Sunset {
            get { return sunset; }
            set { sunset = value; }
        }

        public String Sunrise {
            get { return sunrise; }
            set { sunrise = value; }
        }

        public String Day_of_the_week {
            get { return day_of_the_week; }
            set { day_of_the_week = value; }
        }

        public String Sky_condition {
            get { return sky_condition; }
            set { sky_condition = value; }
        }

        public String Wind {
            get { return wind; }
            set { wind = value; }
        }

        public String Wind_des {
            get { return wind_des; }
            set { wind_des = value; }
        }

        public String Wind_dir {
            get { return wind_dir; }
            set { wind_dir = value; }
        }

        public String Min_temperature {
            get { return min_temperature; }
            set { min_temperature = value; }
        }

        public String Max_temperature {
            get { return max_temperature; }
            set { max_temperature = value; }
        }

        public String Pressure {
            get { return pressure; }
            set { pressure = value; }
        }

        public String Humidity {
            get { return humidity; }
            set { humidity = value; }
        }

        public String Clouds {
            get { return clouds; }
            set { clouds = value; }
        }
    }
}