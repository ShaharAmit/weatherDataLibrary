﻿using System;

namespace WeatherLib
{
    class Program
    {
        public static void Main(string[] args) {
            try {
                // ask to check the service
                IWeatherDataService weatherService = WeatherDataServiceFactory.getWeatherDataService(WeatherDataServiceFactory.OPEN_WEATHER_MAP);
                // if you want different city weather data, this is the place to change it (under new location)
                WeatherData weatherData = weatherService.getWeatherData(new Location("Bangkok"));
                // ask to print weathe rdata
                weatherData.PrintWeatherData();
                //just use the below method to use weather information (don't forget to read and unmark from "WeatherData class" the relevant method
                //Location[]  weatherDataByDays = weatherData.getWeatherInfo;
            }
            catch {
                throw new WeatherDataException("3");
            }
            finally { }
        }
    }
}