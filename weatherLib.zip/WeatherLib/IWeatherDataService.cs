﻿namespace WeatherLib {
    public interface IWeatherDataService {
        WeatherDataServiceFactory getWeatherData(Location location);
    }
}
