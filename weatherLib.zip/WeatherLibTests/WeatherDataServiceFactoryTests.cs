﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WeatherLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// this is a service check. should work unless you have changed it
namespace WeatherLib.Tests {
    [TestClass()]
    public class getWeatherDataServiceTests {
        [TestMethod()]
        public void getWeatherDataTest() {
            Assert.AreEqual(WeatherDataServiceFactory.OPEN_WEATHER_MAP,"OPEN_WEATHER_MAP");
        }


        // if you want to make tests in the following method just change the city name under new loction, and don't forget to change to country code according to the city been chosen.
        // if it works here it would work in the app!
        [TestMethod()]
        public void WeatherDataServiceFactoryTests() {
            IWeatherDataService weatherService = WeatherDataServiceFactory.getWeatherDataService(WeatherDataServiceFactory.OPEN_WEATHER_MAP);
            WeatherData weatherData = weatherService.getWeatherData(new Location("Bangkok"));
            Assert.AreEqual(weatherData.WeatherInformationByDays[0].Country_code, "TH");
        }
    }
}