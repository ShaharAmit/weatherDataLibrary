﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WeatherLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherLib.Tests {
    [TestClass()]
    public class getWeatherDataServiceTests {
        [TestMethod()]
        public void getWeatherDataTest() {
            Assert.AreEqual(WeatherDataServiceFactory.OPEN_WEATHER_MAP,"OPEN_WEATHER_MAP");
        }

        [TestMethod()]
        public void WeatherDataServiceFactoryTests() {
            IWeatherDataService weatherService = WeatherDataServiceFactory.getWeatherDataService(WeatherDataServiceFactory.OPEN_WEATHER_MAP);
            WeatherData weatherData = weatherService.getWeatherData(new Location("Bangkok"));
            Assert.AreEqual(weatherData.WeatherInformationByDays[0].Country_name, "TH");
        }
    }
}