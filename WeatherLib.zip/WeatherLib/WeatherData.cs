﻿using System;

namespace WeatherLib {
    public abstract class WeatherData {
        // holds all the weather data
        private Location[] weatherInfomationByDays = new Location[16];
        
        //use the below method to get the weather data if you know what you are doing
        /*public Location[] getWeatherInfo {
            get { return weatherInfomationByDays; }
        }*/

        public Location[] WeatherInformationByDays {
            get { return weatherInfomationByDays; }
            set { weatherInfomationByDays = value; }
        }
        // pre set to null the weather holder
        public WeatherData() {
            for(int i=0; i<16; i++) {
                weatherInfomationByDays[i] = new Location(null);
            }
        }
        // making the lambada method
        delegate double del(double i);

        //prints all the weather data
        public void PrintWeatherData() {
            //lambada as names
            del celsiusToFahrenheit = x => (x * 1.8) + 32;
            del celsiusToKelvin = x => x + 273.15;
            double fahrenheit;
            double kelvin;

            Console.WriteLine();
            Console.WriteLine("Weather forecast at " + WeatherInformationByDays[0].Country_name + ", " + weatherInfomationByDays[0].City_name +":");
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Sunrise: " + WeatherInformationByDays[0].Sunrise);
            Console.WriteLine("Sunset: " + WeatherInformationByDays[0].Sunset);
            Console.WriteLine("*******************************************************************************");
            Console.WriteLine();

            foreach (Location l in weatherInfomationByDays) {
                Console.WriteLine("Date: " + l.Day_of_the_week);
                Console.WriteLine();
                fahrenheit = celsiusToFahrenheit(Convert.ToDouble(l.Min_temperature));
                kelvin = celsiusToKelvin(Convert.ToDouble(l.Min_temperature));
                Console.WriteLine("Min temperature: " + l.Min_temperature + " °C /" + fahrenheit + " °F /" + kelvin + " K");
                fahrenheit = celsiusToFahrenheit(Convert.ToDouble(l.Max_temperature));
                kelvin = celsiusToKelvin(Convert.ToDouble(l.Max_temperature));
                Console.WriteLine("Max temperature: " + l.Max_temperature + "°C/" + fahrenheit + "°F/" + kelvin + "K");
                Console.WriteLine("Sky condition: " + l.Sky_condition);
                Console.WriteLine("Wind: " + l.Wind_des + " " + l.Wind + " mps directed " + l.Wind_dir);
                Console.WriteLine("Humidity: " + l.Humidity + "%");
                Console.WriteLine("Pressure: " + l.Pressure + " hpa");
                Console.WriteLine("Clouds: " + l.Clouds);
                Console.WriteLine("-------------------------------------------------------------------------------");
                Console.WriteLine("-------------------------------------------------------------------------------");
                Console.WriteLine();
            }
        }
    }
}