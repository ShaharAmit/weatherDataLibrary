﻿using System;
using System.Linq;
using System.Net;
using System.Xml.Linq;

namespace WeatherLib {
    public class WeatherDataServiceFactory : WeatherData, IWeatherDataService {
        const String URL = "http://api.openweathermap.org/data/2.5/forecast/daily?q=";
        const String Key = "&mode=xml&units=metric&appid=565f53596d006ec7a906eedbb8b56182&cnt=16";
        public const String OPEN_WEATHER_MAP = "OPEN_WEATHER_MAP";

        //singelton
        private static WeatherDataServiceFactory weatherDataServiceFactory;
        private WeatherDataServiceFactory() { }
        public static WeatherDataServiceFactory Instance {
            get {
                if (weatherDataServiceFactory == null) {
                    weatherDataServiceFactory = new WeatherDataServiceFactory();
                }
                return weatherDataServiceFactory;
            }
        }

        //checking the service
        public static IWeatherDataService getWeatherDataService(String str) {
            if (str.Equals(OPEN_WEATHER_MAP))
                return Instance;
            else
                throw new WeatherDataException("2");
        }

        //getting weather data
        public WeatherDataServiceFactory getWeatherData(Location location) {
            try {
                int i = 0;
                WebClient client = new WebClient();
                String XML = client.DownloadString(URL + location.City_name + Key);
                XDocument xmlDoc = XDocument.Parse(XML);
                WeatherInformationByDays[0].City_name = xmlDoc.Descendants("name").First().Value;
                WeatherInformationByDays[0].Country_name = xmlDoc.Descendants("country").First().Value;
                WeatherInformationByDays[0].Sunrise = xmlDoc.Descendants("sun").Attributes("rise").First().Value;
                WeatherInformationByDays[0].Sunset = xmlDoc.Descendants("sun").Attributes("set").First().Value;

                foreach (XElement col in xmlDoc.Descendants("time")) {
                    WeatherInformationByDays[i].Day_of_the_week = col.Attributes("day").First().Value;
                    WeatherInformationByDays[i].Sky_condition = col.Element("symbol").Attributes("name").First().Value;
                    WeatherInformationByDays[i].Wind_dir = col.Element("windDirection").Attributes("name").First().Value;
                    WeatherInformationByDays[i].Wind = col.Element("windSpeed").Attributes("mps").First().Value;
                    WeatherInformationByDays[i].Wind_des = col.Element("windSpeed").Attributes("name").First().Value;
                    WeatherInformationByDays[i].Max_temperature = col.Element("temperature").Attributes("max").First().Value;
                    WeatherInformationByDays[i].Min_temperature = col.Element("temperature").Attributes("min").First().Value;
                    WeatherInformationByDays[i].Pressure = col.Element("pressure").Attributes("value").First().Value;
                    WeatherInformationByDays[i].Humidity = col.Element("humidity").Attributes("value").First().Value;
                    WeatherInformationByDays[i].Clouds = col.Element("clouds").Attributes("value").First().Value;
                    i++;
                }
            }
            catch {
                throw new WeatherDataException("1");
            }
            return (WeatherDataServiceFactory)this;
        }
    
    }
}
